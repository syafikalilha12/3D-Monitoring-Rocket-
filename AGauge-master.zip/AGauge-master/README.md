# AGauge
.NET Winforms Gauge Control created based on original work by A.J.Bauer with various improvment.
List of improvement done on top of the original works is described in my page below:<br/>
http://www.codearteng.com/2012/08/agauge-winforms-gauge-control.html

The latest binary package had been published to NuGet Package Gallery named "AGauge V2".<br/>
https://www.nuget.org/packages/AGauge_V2/2.0.2
