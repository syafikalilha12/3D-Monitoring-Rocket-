﻿namespace Csharp_Arduino_Connected_to_Multiple_Sensors
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_comPort = new System.Windows.Forms.ComboBox();
            this.comboBox_baudRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button_open = new System.Windows.Forms.Button();
            this.button_close = new System.Windows.Forms.Button();
            this.textBox_sensor1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_sensor2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_sensor3 = new System.Windows.Forms.TextBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.verticalProgressBar_statusCom = new Csharp_Arduino_Connected_to_Multiple_Sensors.VerticalProgressBar();
            this.verticalProgressBar_sensor3 = new Csharp_Arduino_Connected_to_Multiple_Sensors.VerticalProgressBar();
            this.verticalProgressBar_sensor2 = new Csharp_Arduino_Connected_to_Multiple_Sensors.VerticalProgressBar();
            this.verticalProgressBar_sensor1 = new Csharp_Arduino_Connected_to_Multiple_Sensors.VerticalProgressBar();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.textBox_sensor3);
            this.panel1.Controls.Add(this.verticalProgressBar_sensor3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox_sensor2);
            this.panel1.Controls.Add(this.verticalProgressBar_sensor2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox_sensor1);
            this.panel1.Controls.Add(this.verticalProgressBar_sensor1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(474, 250);
            this.panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.verticalProgressBar_statusCom);
            this.groupBox1.Controls.Add(this.button_close);
            this.groupBox1.Controls.Add(this.button_open);
            this.groupBox1.Controls.Add(this.comboBox_baudRate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox_comPort);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Location = new System.Drawing.Point(0, 256);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(474, 85);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COM PORT SETTINGS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "COM PORT :";
            // 
            // comboBox_comPort
            // 
            this.comboBox_comPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_comPort.FormattingEnabled = true;
            this.comboBox_comPort.Location = new System.Drawing.Point(147, 22);
            this.comboBox_comPort.Name = "comboBox_comPort";
            this.comboBox_comPort.Size = new System.Drawing.Size(121, 25);
            this.comboBox_comPort.TabIndex = 1;
            this.comboBox_comPort.DropDown += new System.EventHandler(this.comboBox_comPort_DropDown);
            // 
            // comboBox_baudRate
            // 
            this.comboBox_baudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_baudRate.FormattingEnabled = true;
            this.comboBox_baudRate.Items.AddRange(new object[] {
            "9600",
            "38400",
            "57600",
            "115200"});
            this.comboBox_baudRate.Location = new System.Drawing.Point(147, 52);
            this.comboBox_baudRate.Name = "comboBox_baudRate";
            this.comboBox_baudRate.Size = new System.Drawing.Size(121, 25);
            this.comboBox_baudRate.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "BAUD RATE :";
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(297, 33);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(70, 30);
            this.button_open.TabIndex = 4;
            this.button_open.Text = "OPEN";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(373, 33);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(70, 30);
            this.button_close.TabIndex = 5;
            this.button_close.Text = "CLOSE";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // textBox_sensor1
            // 
            this.textBox_sensor1.BackColor = System.Drawing.Color.White;
            this.textBox_sensor1.Location = new System.Drawing.Point(93, 196);
            this.textBox_sensor1.Name = "textBox_sensor1";
            this.textBox_sensor1.ReadOnly = true;
            this.textBox_sensor1.Size = new System.Drawing.Size(50, 25);
            this.textBox_sensor1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sensor 1:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(169, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Sensor 2:";
            // 
            // textBox_sensor2
            // 
            this.textBox_sensor2.BackColor = System.Drawing.Color.White;
            this.textBox_sensor2.Location = new System.Drawing.Point(234, 196);
            this.textBox_sensor2.Name = "textBox_sensor2";
            this.textBox_sensor2.ReadOnly = true;
            this.textBox_sensor2.Size = new System.Drawing.Size(50, 25);
            this.textBox_sensor2.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(311, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Sensor 3:";
            // 
            // textBox_sensor3
            // 
            this.textBox_sensor3.BackColor = System.Drawing.Color.White;
            this.textBox_sensor3.Location = new System.Drawing.Point(376, 196);
            this.textBox_sensor3.Name = "textBox_sensor3";
            this.textBox_sensor3.ReadOnly = true;
            this.textBox_sensor3.Size = new System.Drawing.Size(50, 25);
            this.textBox_sensor3.TabIndex = 7;
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // verticalProgressBar_statusCom
            // 
            this.verticalProgressBar_statusCom.Location = new System.Drawing.Point(23, 22);
            this.verticalProgressBar_statusCom.Name = "verticalProgressBar_statusCom";
            this.verticalProgressBar_statusCom.Size = new System.Drawing.Size(35, 55);
            this.verticalProgressBar_statusCom.TabIndex = 0;
            // 
            // verticalProgressBar_sensor3
            // 
            this.verticalProgressBar_sensor3.Location = new System.Drawing.Point(384, 30);
            this.verticalProgressBar_sensor3.Maximum = 1023;
            this.verticalProgressBar_sensor3.Name = "verticalProgressBar_sensor3";
            this.verticalProgressBar_sensor3.Size = new System.Drawing.Size(35, 160);
            this.verticalProgressBar_sensor3.TabIndex = 6;
            // 
            // verticalProgressBar_sensor2
            // 
            this.verticalProgressBar_sensor2.Location = new System.Drawing.Point(242, 30);
            this.verticalProgressBar_sensor2.Maximum = 1023;
            this.verticalProgressBar_sensor2.Name = "verticalProgressBar_sensor2";
            this.verticalProgressBar_sensor2.Size = new System.Drawing.Size(35, 160);
            this.verticalProgressBar_sensor2.TabIndex = 3;
            // 
            // verticalProgressBar_sensor1
            // 
            this.verticalProgressBar_sensor1.Location = new System.Drawing.Point(101, 30);
            this.verticalProgressBar_sensor1.Maximum = 1023;
            this.verticalProgressBar_sensor1.Name = "verticalProgressBar_sensor1";
            this.verticalProgressBar_sensor1.Size = new System.Drawing.Size(35, 160);
            this.verticalProgressBar_sensor1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 341);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Csharp Arduino Connected to Multiple Sensors";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.ComboBox comboBox_baudRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_comPort;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_sensor3;
        private VerticalProgressBar verticalProgressBar_sensor3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_sensor2;
        private VerticalProgressBar verticalProgressBar_sensor2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_sensor1;
        private VerticalProgressBar verticalProgressBar_sensor1;
        private VerticalProgressBar verticalProgressBar_statusCom;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

