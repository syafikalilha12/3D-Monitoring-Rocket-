﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Csharp_Arduino_Connected_to_Multiple_Sensors
{
    public partial class Form1 : Form
    {
        string serialDataIn;
        sbyte indexOfA, indexOfB, indexOfC;
        string dataSensor1, dataSensor2, dataSensor3;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button_open.Enabled = true;
            button_close.Enabled = false;
            verticalProgressBar_statusCom.Value = 0;
            comboBox_baudRate.Text = "115200";
        }

        private void comboBox_comPort_DropDown(object sender, EventArgs e)
        {
            string[] portLists = SerialPort.GetPortNames();
            comboBox_comPort.Items.Clear();
            comboBox_comPort.Items.AddRange(portLists);
        }

        private void button_open_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = comboBox_comPort.Text;
                serialPort1.BaudRate = Convert.ToInt32(comboBox_baudRate.Text);
                serialPort1.Open();

                button_open.Enabled = false;
                button_close.Enabled = true;
                verticalProgressBar_statusCom.Value = 100;
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();

                button_open.Enabled = true;
                button_close.Enabled = false;
                verticalProgressBar_statusCom.Value = 0;
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                serialPort1.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            serialDataIn = serialPort1.ReadLine();
            this.BeginInvoke(new EventHandler(ProcessData));
        }

        private void ProcessData(object sender, EventArgs e)
        {
            try
            {
                indexOfA = Convert.ToSByte( serialDataIn.IndexOf("A"));
                indexOfB = Convert.ToSByte( serialDataIn.IndexOf("B"));
                indexOfC = Convert.ToSByte( serialDataIn.IndexOf("C"));

                dataSensor1 = serialDataIn.Substring(0, indexOfA);
                dataSensor2 = serialDataIn.Substring(indexOfA + 1, (indexOfB - indexOfA) - 1);
                dataSensor3 = serialDataIn.Substring(indexOfB + 1, (indexOfC - indexOfB) - 1);

                textBox_sensor1.Text = dataSensor1;
                textBox_sensor2.Text = dataSensor2;
                textBox_sensor3.Text = dataSensor3;

                verticalProgressBar_sensor1.Value = Convert.ToInt16(dataSensor1);
                verticalProgressBar_sensor2.Value = Convert.ToInt16(dataSensor2);
                verticalProgressBar_sensor3.Value = Convert.ToInt16(dataSensor3);
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
